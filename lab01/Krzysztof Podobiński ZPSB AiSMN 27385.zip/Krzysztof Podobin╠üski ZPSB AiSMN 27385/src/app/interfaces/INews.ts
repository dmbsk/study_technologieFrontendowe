export class INews {
  newsId?: string;
  title: string;
  dateCreated: string;
  description: string;
  tags?: any;
}
