export interface IPhoto {
  photoId: string;
  thumbUrl: string;
  imgUrl: string;
}
