import { SpecialDatePipe } from './special-date.pipe';

describe('SpecialDatePipe', () => {
  it('create an instance', () => {
    const pipe = new SpecialDatePipe();
    expect(pipe).toBeTruthy();
  });
});
