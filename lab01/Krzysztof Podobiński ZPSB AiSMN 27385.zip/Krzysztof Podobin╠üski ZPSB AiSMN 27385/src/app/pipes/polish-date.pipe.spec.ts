import { PolishDatePipe } from './polish-date.pipe';

describe('PolishDatePipe', () => {
  it('create an instance', () => {
    const pipe = new PolishDatePipe();
    expect(pipe).toBeTruthy();
  });
});
